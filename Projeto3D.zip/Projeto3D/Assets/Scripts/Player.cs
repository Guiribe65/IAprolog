﻿using UnityEngine;

public class Player : MonoBehaviour
{

    public float forceMutiplier = 10f;
    public float maximumVelocity = 3f;


    // Use this for initialization
    void Start()
    {

    }
    void movimentacao()
    {
        var EixoXInput = Input.GetAxis("Horizontal");
        if (GetComponent<Rigidbody>().velocity.magnitude <= maximumVelocity)
        {
            if (Input.GetKeyDown(KeyCode.Z))
            {
                GetComponent<Rigidbody>().AddForce(new Vector3(EixoXInput * forceMutiplier, 0, 0));
            }
            GetComponent<Rigidbody>().AddForce(new Vector3(EixoXInput * forceMutiplier, 0, 0));
        }
        var EixoZInput = Input.GetAxis("Vertical");
        if (GetComponent<Rigidbody>().velocity.magnitude <= maximumVelocity)
        {
            GetComponent<Rigidbody>().AddForce(new Vector3(0, 0, EixoZInput * forceMutiplier));
        }

    }
    // Update is called once per frame
    void Update()
    {
        movimentacao();

    }
}
